# ESP32_RTSP_Cam

Simple ESP32 RTSP camera firmware for AI Thinker clone.

Compiles with Arduino IDE 1.8.9 and "ESP32 Wrover Module" board ( https://dl.espressif.com/dl/package_esp32_index.json )

Based on https://github.com/geeksville/Micro-RTSP (use the attached one under the "lib" directory) and https://github.com/Hieromon/AutoConnect.
